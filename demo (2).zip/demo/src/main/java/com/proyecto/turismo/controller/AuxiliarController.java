package com.proyecto.turismo.controller;

import com.proyecto.turismo.model.Auxiliar;
import com.proyecto.turismo.service.AuxiliarService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auxiliares")
public class AuxiliarController {

    @Autowired
    private AuxiliarService auxiliarService;

    @PostMapping
    public ResponseEntity<Auxiliar> crear(@Valid @RequestBody Auxiliar aux) {
        return ResponseEntity.ok(auxiliarService.guardar(aux));
    }

    @GetMapping
    public ResponseEntity<List<Auxiliar>> listar() {
        return ResponseEntity.ok(auxiliarService.listar());
    }


    @GetMapping("/informacion")
    public ResponseEntity<String> info() {
        return ResponseEntity.ok(auxiliarService.brindarInformacion());
    }

    @GetMapping("/reporte")
    public ResponseEntity<String> reporte() {
        return ResponseEntity.ok(auxiliarService.generarReportes());
    }
    @DeleteMapping("/recepcion/{id}")
    public ResponseEntity<String> recepcion(@PathVariable Long id) {
        return ResponseEntity.ok(auxiliarService.registrarRecepcion(id));
    }

}

