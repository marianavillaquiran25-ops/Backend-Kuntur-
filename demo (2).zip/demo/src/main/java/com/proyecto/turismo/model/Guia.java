package com.proyecto.turismo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.proyecto.turismo.model.enums.Rol;

@Entity
@Table(name = "guias")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Guia extends Usuario {

    // DISPONIBILIDAD DEL GUÍA
    private Boolean disponible;

}