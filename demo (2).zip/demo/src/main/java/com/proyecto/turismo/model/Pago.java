package com.proyecto.turismo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "pagos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "El monto es obligatorio")
    private Double monto;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDateTime fecha;

    // Método de pago
    private String metodoPago;

    // Estado del pago
    private String estado;

    // Turista que paga
    @ManyToOne
    @JoinColumn(name = "turista_id")
    private Turista turista;

    // Ruta que está pagando
    @ManyToOne
    @JoinColumn(name = "ruta_id")
    private Ruta ruta;

    // Administrador que registra el pago
    @ManyToOne
    @JoinColumn(name = "administrador_id")
    private Administrador administrador;
}