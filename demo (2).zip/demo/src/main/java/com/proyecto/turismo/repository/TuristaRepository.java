package com.proyecto.turismo.repository;

import com.proyecto.turismo.model.Turista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;



@Repository
public interface TuristaRepository extends JpaRepository<Turista, Long> {

    Optional<Turista> findByDocumentoIdentidad(String documentoIdentidad);

    Optional<Turista> findByCorreo(String correo);

    Optional<Turista> findByTelefono(String telefono);
}