package com.proyecto.turismo.controller;

import com.proyecto.turismo.model.Turista;
import com.proyecto.turismo.service.TuristaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/turistas")
public class TuristaController {

    @Autowired
    private TuristaService turistaService;

    @PostMapping("/register")
public ResponseEntity<Turista> registrar(@Valid @RequestBody Turista turista) {

    Turista nuevoTurista = turistaService.registrarTurista(turista);

    return ResponseEntity.ok(nuevoTurista);
}

@PostMapping("/login")
public ResponseEntity<?> login(@RequestBody Turista turista) {

    Turista usuario = turistaService.login(
            turista.getCorreo(),
            turista.getPassword());

    if (usuario != null) {
        return ResponseEntity.ok(usuario);
    }

    return ResponseEntity.badRequest().body("Usuario o contraseña incorrectos");
}

    // Get para obtener todos los turistas
    @GetMapping
    public ResponseEntity<List<Turista>> listarUsuarios() {
        List<Turista> usuarios = turistaService.listarUsuarios();
        return ResponseEntity.ok(usuarios);
    }

    // Buscar por id
    @GetMapping("/{id}")
    public ResponseEntity<Turista> buscarPorId(@PathVariable Long id) {
        Turista t = turistaService.buscarPorId(id);
        return (t != null) ? ResponseEntity.ok(t) : ResponseEntity.notFound().build();
    }

    // Buscar por Documento
    @GetMapping("/documento/{doc}")
    public ResponseEntity<Turista> buscarPorDocumento(@PathVariable String doc) {
        Turista t = turistaService.buscarPorDocumento(doc);
        return (t != null) ? ResponseEntity.ok(t) : ResponseEntity.notFound().build();
    }

    // Crear Usuario
    @PostMapping
    public ResponseEntity<Turista> crearUsuario(@Valid @RequestBody Turista turista) {
        return ResponseEntity.ok(turistaService.crearUsuario(turista));
    }

    // Actualizar Usuario
    @PutMapping("/{id}")
    public ResponseEntity<Turista> actualizarUsuario(@PathVariable Long id, @Valid @RequestBody Turista turista) {
        Turista actualizado = turistaService.actualizarUsuario(id, turista);
        return (actualizado != null) ? ResponseEntity.ok(actualizado) : ResponseEntity.notFound().build();
    }

    // Eliminar Usuario
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        boolean eliminado = turistaService.eliminarUsuario(id);
        return eliminado ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}