package com.proyecto.turismo.controller;

import com.proyecto.turismo.model.Ruta;
import com.proyecto.turismo.service.RutaService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rutas")

public class RutaController {

    @Autowired
    private RutaService rutaService;

    // LISTAR TODAS LAS RUTAS
    @GetMapping
    public ResponseEntity<List<Ruta>> listarRutas() {

        List<Ruta> rutas = rutaService.listarRutas();

        return ResponseEntity.ok(rutas);
    }

    // BUSCAR RUTA POR ID
    @GetMapping("/{id}")
    public ResponseEntity<Ruta> buscarPorId(
            @PathVariable Long id) {

        Ruta ruta = rutaService.buscarPorId(id);

        return (ruta != null)
                ? ResponseEntity.ok(ruta)
                : ResponseEntity.notFound().build();
    }

    // CREAR RUTA
    @PostMapping
    public ResponseEntity<Ruta> crearRuta(
            @Valid @RequestBody Ruta ruta) {

        return ResponseEntity.ok(
                rutaService.crearRuta(ruta));
    }

    // ACTUALIZAR RUTA
    @PutMapping("/{id}")
    public ResponseEntity<Ruta> actualizarRuta(
            @PathVariable Long id,
            @Valid @RequestBody Ruta ruta) {

        Ruta actualizada =
                rutaService.actualizarRuta(id, ruta);

        return (actualizada != null)
                ? ResponseEntity.ok(actualizada)
                : ResponseEntity.notFound().build();
    }

    // ELIMINAR RUTA
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRuta(
            @PathVariable Long id) {

        boolean eliminada =
                rutaService.eliminarRuta(id);

        return eliminada
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}