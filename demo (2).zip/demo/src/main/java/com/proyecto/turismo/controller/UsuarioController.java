package com.proyecto.turismo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.proyecto.turismo.model.Usuario;
import com.proyecto.turismo.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/usuarios")

@CrossOrigin(origins = "http://localhost:4200")

public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    public UsuarioController(
            UsuarioRepository usuarioRepository) {

        this.usuarioRepository = usuarioRepository;

    }

    @GetMapping
    public List<Usuario> obtenerUsuarios() {

        return usuarioRepository.findAll();

    }

}
