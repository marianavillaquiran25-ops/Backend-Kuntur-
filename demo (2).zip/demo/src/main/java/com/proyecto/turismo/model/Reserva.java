package com.proyecto.turismo.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "reservas")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // FECHA RESERVA
    private LocalDateTime fechaReserva;

    // ESTADO
    private String estado;

    // MUCHAS RESERVAS PARA UN TURISTA
    @ManyToOne
    @JoinColumn(name = "turista_id")
    private Turista turista;

    // MUCHAS RESERVAS PARA UNA RUTA
    @ManyToOne
    @JoinColumn(name = "ruta_id")
    private Ruta ruta;

}