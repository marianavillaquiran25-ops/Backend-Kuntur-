package com.proyecto.turismo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyecto.turismo.model.Usuario;

public interface UsuarioRepository
        extends JpaRepository<Usuario, Long> {

}