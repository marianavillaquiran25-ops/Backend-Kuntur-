package com.proyecto.turismo.controller;

import com.proyecto.turismo.model.Reserva;
import com.proyecto.turismo.service.ReservaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reservas")
@CrossOrigin("*")

public class ReservaController {

    @Autowired
    private ReservaService reservaService;

    // LISTAR
    @GetMapping
    public List<Reserva> listar() {

        return reservaService.listar();

    }

    // GUARDAR
    @PostMapping
    public Reserva guardar(@RequestBody Reserva reserva) {

        return reservaService.guardar(reserva);

    }

}
