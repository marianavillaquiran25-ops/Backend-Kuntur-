package com.proyecto.turismo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.proyecto.turismo.model.Guia;
import com.proyecto.turismo.service.GuiaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/guias")

public class GuiaController {

    @Autowired
    private GuiaService guiaService;

    // LISTAR TODOS LOS GUÍAS
    @GetMapping
    public ResponseEntity<List<Guia>> listarGuias() {

        List<Guia> guias = guiaService.listarGuias();

        return ResponseEntity.ok(guias);
    }

    // BUSCAR GUÍA POR ID
    @GetMapping("/{id}")
    public ResponseEntity<Guia> buscarPorId(@PathVariable Long id) {

        Guia guia = guiaService.buscarPorId(id);

        return (guia != null)
                ? ResponseEntity.ok(guia)
                : ResponseEntity.notFound().build();
    }

    // CREAR GUÍA
    @PostMapping
    public ResponseEntity<Guia> crearGuia(
            @Valid @RequestBody Guia guia) {

        return ResponseEntity.ok(
                guiaService.crearGuia(guia));
    }

    // ACTUALIZAR GUÍA
    @PutMapping("/{id}")
    public ResponseEntity<Guia> actualizarGuia(
            @PathVariable Long id,
            @Valid @RequestBody Guia guia) {

        Guia actualizado =
                guiaService.actualizarGuia(id, guia);

        return (actualizado != null)
                ? ResponseEntity.ok(actualizado)
                : ResponseEntity.notFound().build();
    }

    // ELIMINAR GUÍA
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarGuia(
            @PathVariable Long id) {

        boolean eliminado =
                guiaService.eliminarGuia(id);

        return eliminado
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}