package com.proyecto.turismo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.turismo.model.Administrador;
import com.proyecto.turismo.model.enums.Rol;
import com.proyecto.turismo.repository.AdministradorRepository;

@Service
public class AdministradorService {

    @Autowired
    private AdministradorRepository administradorRepository;

    // LISTAR ADMINISTRADORES
    public List<Administrador> listarAdministradores() {

        return administradorRepository.findAll();
    }

    // BUSCAR ADMINISTRADOR POR ID
    public Administrador buscarPorId(Long id) {

        return administradorRepository.findById(id).orElse(null);
    }

    // CREAR ADMINISTRADOR
    public Administrador crearAdministrador(
            Administrador administrador) {

        // ASIGNAR ROL AUTOMÁTICAMENTE
        administrador.setRol(Rol.ADMINISTRADOR);

        return administradorRepository.save(administrador);
    }

    // ACTUALIZAR ADMINISTRADOR
    public Administrador actualizarAdministrador(
            Long id,
            Administrador administradorActualizado) {

        return administradorRepository.findById(id).map(admin -> {

            admin.setNombre(administradorActualizado.getNombre());
            admin.setCorreo(administradorActualizado.getCorreo());
            admin.setTelefono(administradorActualizado.getTelefono());
            admin.setPassword(administradorActualizado.getPassword());
            admin.setCargo(administradorActualizado.getCargo());

            return administradorRepository.save(admin);

        }).orElse(null);
    }

    // ELIMINAR ADMINISTRADOR
    public boolean eliminarAdministrador(Long id) {

        if (administradorRepository.existsById(id)) {

            administradorRepository.deleteById(id);

            return true;
        }

        return false;
    }
}