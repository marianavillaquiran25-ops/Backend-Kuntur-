package com.proyecto.turismo.service;

import com.proyecto.turismo.model.Ruta;
import com.proyecto.turismo.repository.RutaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RutaService {

    @Autowired
    private RutaRepository rutaRepository;

    // LISTAR TODAS LAS RUTAS
    public List<Ruta> listarRutas() {

        return rutaRepository.findAll();
    }

    // BUSCAR RUTA POR ID
    public Ruta buscarPorId(Long id) {

        return rutaRepository.findById(id).orElse(null);
    }
    public Ruta crearRuta(Ruta ruta) {

    // ACTIVAR RUTA AUTOMÁTICAMENTE
    ruta.setActiva(true);

    return rutaRepository.save(ruta);

    }

    // ACTUALIZAR RUTA
    public Ruta actualizarRuta(Long id, Ruta rutaActualizada) {

        return rutaRepository.findById(id).map(ruta -> {

            ruta.setNombre(rutaActualizada.getNombre());
            ruta.setDestino(rutaActualizada.getDestino());
            ruta.setDescripcion(rutaActualizada.getDescripcion());
            ruta.setImagen(rutaActualizada.getImagen());
            ruta.setPrecio(rutaActualizada.getPrecio());
            ruta.setCuposDisponibles(rutaActualizada.getCuposDisponibles());
            ruta.setDuracion(rutaActualizada.getDuracion());
            ruta.setActiva(rutaActualizada.getActiva());
            ruta.setGuia(rutaActualizada.getGuia());

            return rutaRepository.save(ruta);

        }).orElse(null);
    }

    // ELIMINAR RUTA
    public boolean eliminarRuta(Long id) {

        if (rutaRepository.existsById(id)) {

            rutaRepository.deleteById(id);

            return true;
        }

        return false;
    }
}