package com.proyecto.turismo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "administradores")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Administrador extends Usuario {

    // CARGO DEL ADMINISTRADOR
    private String cargo;

}