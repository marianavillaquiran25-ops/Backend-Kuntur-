package com.proyecto.turismo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.proyecto.turismo.model.Auxiliar;

@Repository
public interface AuxiliarRepository extends JpaRepository<Auxiliar, Long> {

    Optional<Auxiliar> findByCorreo(String correo);

    Optional<Auxiliar> findByTelefono(String telefono);

}