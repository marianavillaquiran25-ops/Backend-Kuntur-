package com.proyecto.turismo.service;

import com.proyecto.turismo.repository.*; // Importa tus repositorios
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    @Autowired
    private AdministradorRepository administradorRepository;

    @Autowired
    private AuxiliarRepository auxiliarRepository;

    @Autowired
    private TuristaRepository turistaRepository;

    
    public String logicadeNegocioUsuario(String correo) {
        
        // 1. Si correo = admin@correo.com -> Inicia Sesión como administrador
        if (correo.equalsIgnoreCase("admin@correo.com")) {
            // Verificamos si existe en la tabla de administradores
            if (administradorRepository.findByCorreo(correo).isPresent()) {
                return "Administrador";
            }
        }

        // 2. Si correo = auxiliar@correo.com -> Inicia Sesión como AUXILIAR
        // Omitimos el paso de "Empleado" genérico y vamos directo a Auxiliar
        if (correo.equalsIgnoreCase("auxiliar@correo.com")) {
            if (auxiliarRepository.findByCorreo(correo).isPresent()) {
                return "AUXILIAR";
            }
        }

        // Si no es ninguno de los anteriores, verificamos si existe como turista
        if (turistaRepository.findByCorreo(correo).isPresent()) {
            return "TURISTA";
        }

        return "USUARIO NO REGISTRADO";
    }
}

