package com.proyecto.turismo.service;

import com.proyecto.turismo.model.Reserva;
import com.proyecto.turismo.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    // LISTAR
    public List<Reserva> listar() {

        return reservaRepository.findAll();

    }

    // GUARDAR
    public Reserva guardar(Reserva reserva) {

        return reservaRepository.save(reserva);

    }

}
