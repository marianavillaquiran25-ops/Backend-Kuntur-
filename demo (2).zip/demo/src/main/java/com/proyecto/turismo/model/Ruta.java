package com.proyecto.turismo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "rutas")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Ruta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // NOMBRE DE LA RUTA
    @NotBlank(message = "El nombre de la ruta es obligatorio")
    private String nombre;

    // DESTINO
    @NotBlank(message = "El destino es obligatorio")
    private String destino;

    // DESCRIPCIÓN
    @NotBlank(message = "La descripción es obligatoria")
    private String descripcion;

    @Column(length = 1000)
    private String imagen;

    // PRECIO
    @NotNull(message = "El precio es obligatorio")
    private Double precio;

    // CUPOS DISPONIBLES
    @NotNull(message = "Los cupos son obligatorios")
    private Integer cuposDisponibles;

    // DURACIÓN
    @NotBlank(message = "La duración es obligatoria")
    private String duracion;

    // ESTADO DE LA RUTA
    private Boolean activa;

    // ADMINISTRADOR QUE CREA LA RUTA
    @ManyToOne
    @JoinColumn(name = "administrador_id")
    private Administrador administrador;

    // GUÍA ASIGNADO A LA RUTA
    @ManyToOne
    @JoinColumn(name = "guia_id")
    private Guia guia;
}