package com.proyecto.turismo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyecto.turismo.model.enums.Rol;
import com.proyecto.turismo.model.Guia;
import com.proyecto.turismo.repository.GuiaRepository;

@Service
public class GuiaService {

    @Autowired
    private GuiaRepository guiaRepository;

    // LISTAR TODOS LOS GUÍAS
    public List<Guia> listarGuias() {
        return guiaRepository.findAll();
    }

    // BUSCAR POR ID
    public Guia buscarPorId(Long id) {
        return guiaRepository.findById(id).orElse(null);
    }

    // CREAR GUÍA
    public Guia crearGuia(Guia guia) {

        // ASIGNAR ROL AUTOMÁTICAMENTE
        guia.setRol(Rol.GUIA);

        return guiaRepository.save(guia);
    }

    // ACTUALIZAR GUÍA
    public Guia actualizarGuia(Long id, Guia guiaActualizado) {

        return guiaRepository.findById(id).map(guia -> {

            guia.setNombre(guiaActualizado.getNombre());
            guia.setCorreo(guiaActualizado.getCorreo());
            guia.setTelefono(guiaActualizado.getTelefono());
            guia.setPassword(guiaActualizado.getPassword());
            guia.setDisponible(guiaActualizado.getDisponible());

            return guiaRepository.save(guia);

        }).orElse(null);
    }

    // ELIMINAR GUÍA
    public boolean eliminarGuia(Long id) {

        if (guiaRepository.existsById(id)) {

            guiaRepository.deleteById(id);

            return true;
        }

        return false;
    }
}