package com.proyecto.turismo.model.enums;

public enum Rol{
    ADMINISTRADOR,
    TURISTA,
    GUIA,
    AUXILIAR

}