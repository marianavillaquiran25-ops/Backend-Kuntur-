package com.proyecto.turismo.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "turistas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"inscripciones", "pagos"})
public class Turista extends Usuario {

    // ATRIBUTOS ESPECÍFICOS DE TURISTA 
    private String nacionalidad;
    private String afeccionesAlergias;

    // RELACIONES
    
    // Relación para "Ver inscripciones" e "Inscribirse"
    @OneToMany(mappedBy = "turista", cascade = CascadeType.ALL)
    private List<Inscripcion> inscripciones;

    // Relación para "Realizar pago"
    @OneToMany(mappedBy = "turista")
    private List<Pago> pagos;
}