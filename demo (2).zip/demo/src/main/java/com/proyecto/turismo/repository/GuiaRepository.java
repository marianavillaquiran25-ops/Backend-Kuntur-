package com.proyecto.turismo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.proyecto.turismo.model.Guia;

@Repository
public interface GuiaRepository extends JpaRepository<Guia, Long> {

    Optional<Guia> findByCorreo(String correo);

    Optional<Guia> findByTelefono(String telefono);

}
