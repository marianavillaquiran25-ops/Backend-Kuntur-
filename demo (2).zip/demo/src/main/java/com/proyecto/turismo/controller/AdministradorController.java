package com.proyecto.turismo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.proyecto.turismo.model.Administrador;
import com.proyecto.turismo.service.AdministradorService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/administradores")

public class AdministradorController {

    @Autowired
    private AdministradorService administradorService;

    // LISTAR ADMINISTRADORES
    @GetMapping
    public ResponseEntity<List<Administrador>>
    listarAdministradores() {

        List<Administrador> administradores =
                administradorService.listarAdministradores();

        return ResponseEntity.ok(administradores);
    }

    // BUSCAR ADMINISTRADOR POR ID
    @GetMapping("/{id}")
    public ResponseEntity<Administrador>
    buscarPorId(@PathVariable Long id) {

        Administrador administrador =
                administradorService.buscarPorId(id);

        return (administrador != null)
                ? ResponseEntity.ok(administrador)
                : ResponseEntity.notFound().build();
    }

    // CREAR ADMINISTRADOR
    @PostMapping
    public ResponseEntity<Administrador>
    crearAdministrador(
            @Valid @RequestBody Administrador administrador) {

        return ResponseEntity.ok(
                administradorService.crearAdministrador(
                        administrador));
    }

    // ACTUALIZAR ADMINISTRADOR
    @PutMapping("/{id}")
    public ResponseEntity<Administrador>
    actualizarAdministrador(
            @PathVariable Long id,
            @Valid @RequestBody Administrador administrador) {

        Administrador actualizado =
                administradorService.actualizarAdministrador(
                        id,
                        administrador);

        return (actualizado != null)
                ? ResponseEntity.ok(actualizado)
                : ResponseEntity.notFound().build();
    }

    // ELIMINAR ADMINISTRADOR
    @DeleteMapping("/{id}")
    public ResponseEntity<Void>
    eliminarAdministrador(
            @PathVariable Long id) {

        boolean eliminado =
                administradorService.eliminarAdministrador(id);

        return eliminado
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
