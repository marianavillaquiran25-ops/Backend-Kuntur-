package com.proyecto.turismo.service;

import com.proyecto.turismo.model.Turista;
import com.proyecto.turismo.model.enums.Rol;
import com.proyecto.turismo.repository.TuristaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TuristaService {

    @Autowired
    private TuristaRepository turistaRepository;

    public Turista registrarTurista(Turista turista) {

    turista.setRol(Rol.TURISTA);

    return turistaRepository.save(turista);
}

public Turista login(String usuario, String password) {

    Turista turista = turistaRepository.findByCorreo(usuario)
            .orElseGet(() -> turistaRepository.findByTelefono(usuario).orElse(null));

    if (turista != null && turista.getPassword().equals(password)) {
        return turista;
    }

    return null;
}

    // Listar todos los turistas
    public List<Turista> listarUsuarios() {
        return turistaRepository.findAll();
    }

    // Buscar por id
    public Turista buscarPorId(Long id) {
        return turistaRepository.findById(id).orElse(null);
    }

    // Buscar por Documento de Identidad
    public Turista buscarPorDocumento(String documento) {
        return turistaRepository.findByDocumentoIdentidad(documento).orElse(null);
    }

    // Crear usuario
    public Turista crearUsuario(Turista turista) {
        return turistaRepository.save(turista);
    }

    // Actualizar usuario
    public Turista actualizarUsuario(Long id, Turista turistaActualizado) {
        return turistaRepository.findById(id).map(turista -> {
            turista.setNombre(turistaActualizado.getNombre());
            turista.setTelefono(turistaActualizado.getTelefono());
            turista.setCorreo(turistaActualizado.getCorreo());
            turista.setPassword(turistaActualizado.getPassword());
            turista.setNacionalidad(turistaActualizado.getNacionalidad());
            return turistaRepository.save(turista);
        }).orElse(null);
    }

    // Eliminar usuario por id 
    public boolean eliminarUsuario(Long id) {
        if (turistaRepository.existsById(id)) {
            turistaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}