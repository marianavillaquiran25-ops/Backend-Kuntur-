package com.proyecto.turismo.controller;

import com.proyecto.turismo.model.Pago;
import com.proyecto.turismo.service.PagoService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
@CrossOrigin("*")
public class PagoController {

    @Autowired
    private PagoService pagoService;

    // Obtener todos los pagos
    @GetMapping
    public ResponseEntity<List<Pago>> listarPagos() {

        return ResponseEntity.ok(
                pagoService.listarPagos()
        );
    }

    // Buscar pago por id
    @GetMapping("/{id}")
    public ResponseEntity<Pago> buscarPorId(
            @PathVariable Long id) {

        Pago pago = pagoService.buscarPorId(id);

        return pago != null
                ? ResponseEntity.ok(pago)
                : ResponseEntity.notFound().build();
    }

    // Crear pago
    @PostMapping
    public ResponseEntity<Pago> crearPago(
            @Valid @RequestBody Pago pago) {

        return ResponseEntity.ok(
                pagoService.crearPago(pago)
        );
    }

    // Actualizar pago
    @PutMapping("/{id}")
    public ResponseEntity<Pago> actualizarPago(
            @PathVariable Long id,
            @Valid @RequestBody Pago pago) {

        Pago actualizado =
                pagoService.actualizarPago(id, pago);

        return actualizado != null
                ? ResponseEntity.ok(actualizado)
                : ResponseEntity.notFound().build();
    }

    // Eliminar pago
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPago(
            @PathVariable Long id) {

        boolean eliminado =
                pagoService.eliminarPago(id);

        return eliminado
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}