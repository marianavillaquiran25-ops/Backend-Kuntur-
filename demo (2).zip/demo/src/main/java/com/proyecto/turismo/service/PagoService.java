package com.proyecto.turismo.service;

import com.proyecto.turismo.model.Pago;
import com.proyecto.turismo.repository.PagoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PagoService {

    @Autowired
    private PagoRepository pagoRepository;

    // Listar pagos
    public List<Pago> listarPagos() {
        return pagoRepository.findAll();
    }

    // Buscar pago por id
    public Pago buscarPorId(Long id) {
        return pagoRepository.findById(id).orElse(null);
    }

    // Crear pago
    public Pago crearPago(Pago pago) {
        return pagoRepository.save(pago);
    }

    // Actualizar pago
    public Pago actualizarPago(Long id, Pago pagoActualizado) {

        return pagoRepository.findById(id).map(pago -> {

            pago.setMonto(pagoActualizado.getMonto());
            pago.setFecha(pagoActualizado.getFecha());
            pago.setMetodoPago(pagoActualizado.getMetodoPago());
            pago.setEstado(pagoActualizado.getEstado());
            pago.setRuta(pagoActualizado.getRuta());
            pago.setTurista(pagoActualizado.getTurista());
            pago.setAdministrador(pagoActualizado.getAdministrador());

            return pagoRepository.save(pago);

        }).orElse(null);
    }

    // Eliminar pago
    public boolean eliminarPago(Long id) {

        if (pagoRepository.existsById(id)) {

            pagoRepository.deleteById(id);
            return true;
        }

        return false;
    }
}