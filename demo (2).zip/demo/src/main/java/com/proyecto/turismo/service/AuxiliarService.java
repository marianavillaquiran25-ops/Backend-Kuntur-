package com.proyecto.turismo.service;

import com.proyecto.turismo.model.Auxiliar;
import com.proyecto.turismo.repository.AuxiliarRepository;
import com.proyecto.turismo.repository.TuristaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuxiliarService {

    @Autowired
    private AuxiliarRepository auxiliarRepository;
    
    @Autowired
    private TuristaRepository turistaRepository;


    //  Atender usuarios: Podría ser una lógica para registrar una consulta
    public String atenderUsuario(Long idTurista) {
        return "Atendiendo al usuario con ID: " + idTurista;
    }

    // Brindar información: Devuelve información general del sistema
    public String brindarInformacion() {
        return "Información de Territorios de Paz: Rutas activas en Támesis y horarios de atención.";
    }

    //  Registrar recepción: Lógica para marcar la llegada de un turista
    public String registrarRecepcion(Long idTurista) {
        return "Recepción registrada para el turista " + idTurista;
    }

    // Supervisar sistema: Consulta rápida de estados
    public String supervisarSistema() {
        return "Estado del sistema: Operativo. Conexión a DB: OK.";
    }

    //  Generar reportes: Reporte sencillo de atención
    public String generarReportes() {
        long totalAtendidos = turistaRepository.count();
        return "Reporte del Auxiliar: Se han atendido " + totalAtendidos + " usuarios en este ciclo.";
    }

    // CRUD BÁSICO 
    public Auxiliar guardar(Auxiliar aux) { return auxiliarRepository.save(aux); }
    public List<Auxiliar> listar() { return auxiliarRepository.findAll(); }
}